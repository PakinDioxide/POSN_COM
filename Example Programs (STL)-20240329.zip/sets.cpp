#include <iostream>
#include <iterator>
#include <set>

using namespace std;

struct Student{
    int age;
    int score;
    int id;
    Student(int a, int s, int i){
        age = a;
        score = s;
        id = i;
    }
};

struct Comparator_id {
    bool operator()(Student const& s1, Student const& s2)
    {
        return s1.id < s2.id;
    }
};

struct Comparator_Score {
    bool operator()(Student const& s1, Student const& s2)
    {
        return s1.score < s2.score;
    }
};


int main(){
    set<int> myset;
    myset.insert(1);
    myset.insert(2);
    myset.insert(2);
    myset.insert(120);
    myset.insert(140);
    myset.insert(150);
    myset.insert(70);


    for (auto it=myset.begin();it!=myset.end();it++){
        cout << *it << endl;
    }

    cout << "lower/upper bounds 100-150:" << endl;
    auto lter = myset.lower_bound(100);
    auto uter = myset.upper_bound(150);
    for (auto it=lter;it!=uter;it++){
        cout << *it << endl;
    }
    cout << "lower/upper bounds 100-145:" << endl;
    lter = myset.lower_bound(100);
    uter = myset.upper_bound(145);
    for (auto it=lter;it!=uter;it++){
        cout << *it << endl;
    }

    std::set<Student, Comparator_id> sic;

    sic.insert(Student(16, 100, 640003));
    sic.insert(Student(19, 100, 640003));
    sic.insert(Student(17, 84, 640004));
    sic.insert(Student(14, 99, 640001));
    sic.insert(Student(19, 94, 640002));
    sic.insert(Student(19, 95, 640002));
    sic.insert(Student(19, 96, 640005));

    cout << "Custom Set (ID Comparator):" << endl;
    for (auto it=sic.begin();it!=sic.end();it++){
        cout << "id: "<< (*it).id << ",";
        cout << "score: "<< (*it).score << ",";
        cout << "age: "<< (*it).age << endl;
    }

    std::set<Student, Comparator_Score> ssc;

    ssc.insert(Student(16, 100, 640003));
    ssc.insert(Student(19, 100, 640003));
    ssc.insert(Student(17, 84, 640004));
    ssc.insert(Student(14, 99, 640001));
    ssc.insert(Student(19, 94, 640002));
    ssc.insert(Student(19, 95, 640002));
    ssc.insert(Student(19, 96, 640005));

    auto clter = ssc.lower_bound(Student(19, 94, 640002));
    auto cuter = ssc.upper_bound(Student(19, 97, 640002));
    cout << "lower/upper bounds (score) 94-97:" << endl;
    for (auto it=clter;it!=cuter;it++){
        cout << "id: "<< (*it).id << ",";
        cout << "score: "<< (*it).score << ",";
        cout << "age: "<< (*it).age << endl;
    }

    //


}
