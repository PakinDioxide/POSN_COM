#include <vector>
#include <iostream>
using namespace std;

int main(){

    vector<int> mylist;

    mylist.push_back(100);
    mylist.push_back(200);
    mylist.push_back(300);

    vector<int>::iterator first = mylist.begin();
    vector<int>::iterator last = mylist.end();

    cout << "First address: " << &first << endl;
    cout << "First value" << *first << endl;

    for (auto it=mylist.begin(); it<mylist.end(); it++)
        cout << *it << endl;

    mylist.pop_back();

    cout << "Array after calling pop_back() ... " << endl;

    for (int i=0; i<mylist.size();i++)
        cout << mylist[i] << endl;

    mylist.push_back(700);

    cout << "front(): " << mylist.front() << endl;
    cout << "back(): " << mylist.back() << endl;

    cout << "Arithmetic operations for Iterator" << endl;

    cout << "1st position: " << *mylist.begin() << endl;
    cout << "2st position: " << *(mylist.begin()+1) << endl;
    cout << "3st position: " << *(mylist.begin()+2) << endl;

    mylist.erase(mylist.begin()+1);

    cout << "Array after calling erase(mylist.begin()+2) ... " << endl;

    for (int i=0; i<mylist.size();i++)
        cout << mylist[i] << endl;

    return 0;
}
