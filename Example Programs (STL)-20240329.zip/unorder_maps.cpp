#include <iostream>
#include <iterator>
#include <map>
#include <unordered_map>

using namespace std;

int main(){
    unordered_map<int, string> mymap;
    mymap.insert({1, "One"});
    mymap.insert({2, "Two"});
    mymap.insert({2, "Three"});       // Not inserted.
    mymap.insert({3, "Two"});
    mymap.insert(make_pair(7, "Seven"));
    mymap.insert(make_pair(9, "Nine"));
    mymap.insert(make_pair(5, "Seven"));

    for (auto it=mymap.begin();it!=mymap.end();it++){
        cout << it->first << ","<< it->second << endl;
    }

    cout << "Call mymap[2]: "<< mymap[2] << endl;
    cout << "Call mymap.find(2)->second: "<< mymap.find(2)->second << endl;

    // Check if there is a specified key in the map

    if (mymap.find(7) == mymap.end()) cout << "7 is not in the map." << endl;
    else cout << "7 is in the map." << endl;

    if (mymap.find(2) == mymap.end()) cout << "2 is not in the map." << endl;
    else cout << "2 is in the map." << endl;

    // Remove an element at a specified key.

    mymap.erase(2);
    cout << "After removing the map pair which has 2 as the key." << endl;
    for (auto it=mymap.begin();it!=mymap.end();it++){
        cout << it->first << ","<< it->second << endl;
    }

    /*
    auto lwb = mymap.lower_bound(5);
    auto upb = mymap.upper_bound(10);

    cout << "Upper/Lower bound 5-10" << endl;
    for (auto it=lwb;it!=upb;it++){
        cout << it->first << ","<< it->second << endl;
    }
    */



}
