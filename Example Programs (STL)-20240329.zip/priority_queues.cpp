#include <iostream>
#include <queue>
#include <stack>
using namespace std;

struct Student{
    int age;
    int score;
    int id;
    Student(int a, int s, int i){
        age = a;
        score = s;
        id = i;
    }
};

struct Comparator_Age {
    bool operator()(Student const& s1, Student const& s2)
    {
        return s1.age < s2.age;
    }
};
struct Comparator_Score {
    bool operator()(Student const& s1, Student const& s2)
    {
        return s1.score > s2.score;
    }
};

int main(){

    queue<int> q;

    q.push(100);
    q.push(-100);
    q.push(200);
    q.push(10);
    q.push(999);

    cout << "Queue:" << endl;
    while (!q.empty()) {
        cout << q.front() << endl;
        q.pop();
    }

    stack<int> mystack;
    mystack.push(100);
    mystack.push(-100);
    mystack.push(200);
    mystack.push(10);
    mystack.push(999);
    cout << "Stack:" << endl;
    while (!mystack.empty()) {
        cout << mystack.top() << endl;
        mystack.pop();
    }



    priority_queue<int> pq;

    pq.push(100);
    pq.push(-100);
    pq.push(200);
    pq.push(10);
    pq.push(999);

    cout << "Priority Queue:" << endl;
    while (!pq.empty()) {
        cout << pq.top() << endl;
        pq.pop();
    }

    priority_queue<Student, vector<Student>, Comparator_Age> ca_pq;

    ca_pq.push(Student(14, 99, 640001));
    ca_pq.push(Student(19, 94, 640002));
    ca_pq.push(Student(16, 100, 640003));

    cout << "Custom Priority Queue (Age Comparator):" << endl;
    while (!ca_pq.empty()) {
        cout << "id: "<< ca_pq.top().id << ",";
        cout << "score: "<< ca_pq.top().score << ",";
        cout << "age: "<< ca_pq.top().age << endl;
        ca_pq.pop();
    }


    priority_queue<Student, vector<Student>, Comparator_Score> cs_pq;

    cs_pq.push(Student(14, 99, 640001));
    cs_pq.push(Student(19, 94, 640002));
    cs_pq.push(Student(16, 100, 640003));

    cout << "Custom Priority Queue (Score Comparator):" << endl;
    while (!cs_pq.empty()) {
        cout << "id: "<< cs_pq.top().id << ",";
        cout << "score: "<< cs_pq.top().score << ",";
        cout << "age: "<< cs_pq.top().age << endl;
        cs_pq.pop();
    }


    return 0;
}
