#include <bits/stdc++.h>

using namesapce std;

vector <int> par;

int fi(int x) {
    if (par[x] != x) par[x] = fi(par[x]);
    return par[x];
}

void uni(int x, int y) {
    par[fi(x)] = fi(y);
}

int main() {
    int n, m;
    cin >> n, m;
    par.resize(n);
    for (int i = 0; i < n; i++) par[i] = i;
    
}