#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int n, k;
    cin >> n >> k;
    long long a[n+1], ans = 0, idx;
    deque <pair <long long, long long>> dq;
    a[0] = 0;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        a[i] += a[i-1];
        while (!dq.empty() && dq.front().second < i-k) dq.pop_front();
        while (!dq.empty() && dq.back().first >= a[i]) dq.pop_back();
        dq.emplace_back(a[i], i);
        if (a[i] - dq.front().first > ans) {
            ans = a[i] - dq.front().first;
            idx = i - dq.front().second;
        } else if (a[i] - dq.front().first == ans) idx = min(idx, i - dq.front().second);
    }
    cout << ans << '\n' << (ans == 0 ? 0 : idx);
}