#include <bits/stdc++.h>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;
    int a[n][m], dp[n][m];
    for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) cin >> a[i][j];
    dp[0][0] = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == 0 && j == 0) continue;
            int k = INT_MAX;
            if (i > 0) k = min(k, dp[i-1][j] + abs(a[i-1][j]-a[i][j]));
            if (j > 0) k = min(k, dp[i][j-1] + abs(a[i][j-1]-a[i][j]));
            dp[i][j] = k;
        }
    }
    cout << dp[n-1][m-1];
}