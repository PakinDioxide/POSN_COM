#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int n;
    cin >> n;
    vector <pair <int, int>> adj[n];
    for (int i = 0; i < n-1; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        u--;
        v--;
        adj[u].emplace_back(v, w);
        adj[v].emplace_back(u, w);
    }
    vector <int> dis(n, INT_MAX), vis(n);
    dis[0] = 0;
    priority_queue <pair <int, int>> q;
    q.emplace(0, 0);
    while (!q.empty()) {
        int u = q.top().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        for (auto x : adj[u]) {
            int v = x.first, w = x.second;
            if (dis[u] + w < dis[v]) {
                dis[v] = dis[u] + w;
                q.emplace(-dis[v], v);
            }
        }
    }
    int ans = 0;
    for (auto i : dis) ans = max(i, ans);
    cout << ans;
}