#include <bits/stdc++.h>

using namespace std;

int main() {
    long long n;
    cin >> n;
    long long a[n];
    for (long long i = 0; i < n; i++) cin >> a[i];
    for (long long i = 0; i < n; i++) {long long x; cin >> x; a[i] -= x;}
    vector <long long> d;
    d.push_back(a[0]);
    for (long long i = 1; i < n; i++) {
        long long idx = upper_bound(d.begin(), d.end(), a[i]) - d.begin();
        if (idx == d.size()) d.push_back(a[i]);
        else if (d[idx-1] <= a[i] && a[i] <= d[idx]) d[idx] = a[i];
    }
    cout << d.size();
}