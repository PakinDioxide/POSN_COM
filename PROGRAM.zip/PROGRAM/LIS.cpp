#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    cin >> n;
    int a[n+1], dp[n+1];
    dp[0] = 0;
    a[0] = INT_MIN;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        for (int j = i-1; j >= 0; j--) {
            if (a[i] >= a[j]) {
                dp[i] = dp[j] + 1;
                break;
            }
        }
    }
    cout << dp[n];
}