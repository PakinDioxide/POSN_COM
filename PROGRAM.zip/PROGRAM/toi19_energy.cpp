#include <bits/stdc++.h>

using namespace std;

long long n, k, d, a[333], tree[1024], m, ans = 0, MOD = 1e9+7;

pair <long long, long long> build(int c) {
    if (c >= m-1) return {tree[c], 1};
    pair <long long, long long> x = build(2*c+1), y = build(2*c+2);
    if (x.second == 0 || y.second == 0 || abs(x.first - y.first) > d) return {0, 0};
    tree[c] = x.first + y.first;
    return {tree[c], 1};
}

void cut(int c, int b) {
    if (c == m) {
        pair <long long, long long> x = build(0);
        if (x.second) ans = (ans+1)%MOD;
        return;
    }
    tree[c+m-1] = 0;
    if (c == m-1) {
        for (int i = b+1; i < n; i++) tree[c+m-1] += a[i];
        if (b < n-1 && abs(tree[c+m-1] - tree[c+m-2]) <= d) cut(c+1, n-1);
        return;
    }
    if (c % 2 == 0) {
        for (int i = b+1; i < n; i++) {
            tree[c+m-1] += a[i];
            cut(c+1, i);
        }
    } else {
        for (int i = b+1; i < n && tree[c+m-1] + a[i] - tree[c+m-2] <= d; i++) {
            tree[c+m-1] += a[i];
            if (abs(tree[c+m-1] - tree[c+m-2]) <= d) cut(c+1, i);
        }
    }
}

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    cin >> n >> k >> d;
    for (int i = 0; i < n; i++) cin >> a[i];
    m = pow(2, k-1);
    cut(0, -1);
    cout << ans;
    return 0;
}