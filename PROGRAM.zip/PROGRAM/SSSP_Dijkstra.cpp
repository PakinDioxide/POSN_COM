#include <bits/stdc++.h>

using namespace std;

int n;
vector <vector <pair <int, int>>> adj;

void dijkstra(int s) {
    vector <int> dis(n, INT_MAX), vis(n);
    priority_queue <pair <int, int>> q;
    dis[s] = 0;
    q.emplace(0, s);
    while (!q.empty()) {
        int u = q.top().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        for (auto x : adj[u]) {
            int v = x.first, w = x.second;
            if (dis[u] + w < dis[v]) {
                dis[v] = dis[u] + w;
                q.emplace(-dis[v], v);
            }
        }
    }
    for (auto i : dis) cout << i << ' ';
    cout << '\n';
}

void 

int main() {
    int m;
    cin >> n >> m;
    adj.resize(n);
    for (int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].emplace_back(v, w);
    }
    dijkstra(2);
}

/*
5 7
0 4 1
1 3 3
1 4 6
2 1 2
2 3 7
2 0 6
3 4 5
*/