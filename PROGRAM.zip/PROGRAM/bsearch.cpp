#include <iostream>

using namespace std;

int a[50000];

int bs(int l, int r, int k) {
    if (l == r) {
        if (a[l] == k) return l;
        else return -1;
    }
    int mid = l + (r-l)*(k-a[l])/(a[r]-a[l]); // make it faster
    if (a[mid] < k) {
        return bs(l+1, r, k);
    } else if (a[mid] > k) {
        return bs(l, r-1, k);
    }
    return mid;
}

int bsn(int l, int r, int k) {
    if (l == r) {
        if (a[l] == k) return l;
        else return -1;
    }
    int mid = (l+r)/2;
    if (a[mid] < k) {
        return bsn(l+1, r, k);
    } else if (a[mid] > k) {
        return bsn(l, r-1, k);
    }
    return mid;
}

int main() {
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) cin >> a[i];
    int k;
    cin >> k;
    cout << bs(0, n-1, k) << '\n';
}