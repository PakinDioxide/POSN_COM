#include <bits/stdc++.h>

using namespace std;

int main() {
    int n, m, s, d, p;
    cin >> n >> m;
    vector <vector <pair <int, int>>> adj(n);
    for (int i = 0; i < m; i++) {
        int x, y, w;
        cin >> x >> y >> w;
        x--;
        y--;
        adj[x].push_back({y, w});
        adj[y].push_back({y, x});
    }
    cin >> s >> d >> p;
    s--;
    d--;
    vector <pair <int, int>> dis(n);
    vector <int> vis(n);
    dis[s] = {0, INT_MAX};
    priority_queue <pair <int, int>> q;
    q.push({0, s});
    while (!q.empty()) {
        int u = q.top().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        for (auto k : adj[u]) {
            int v = k.first, w = k.second;
            if (dis[u].first + w > dis[v].first) {
                dis[v].first = dis[u].first + w;
                dis[v].second = min(w, dis[u].second);
                q.push({dis[v].first, v});
            }
        }
    }
    cout << ceil(p/(dis[d].second-1));
}