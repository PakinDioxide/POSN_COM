#include <bits/stdc++.h>

using namespace std;

int main() {
    vector <int> a = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
    cout << upper_bound(a.begin(), a.end(), 3) - a.begin();
}