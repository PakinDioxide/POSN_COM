#include <bits/stdc++.h>

using namespace std;

struct heap {
    int arr[1000];
    int siz;
};

void makeheap(struct heap *h, int n) {
    if (2*n > h->siz) return;
    int k = h->arr[n*2];
    if (n*2+1 <= h->siz) k = min(k, h->arr[n*2+1]);
    if (k >= h->arr[n]) return;
    if (k == h->arr[2*n]) {
        int temp = h->arr[2*n];
        h->arr[2*n] = h->arr[n];
        h->arr[n] = temp;
        makeheap(h, 2*n);
    } else {
        int temp = h->arr[2*n+1];
        h->arr[2*n+1] = h->arr[n];
        h->arr[n] = temp;
        makeheap(h, 2*n+1);
    }
}

int main() {
    int n;
    struct heap *h;
    cin >> n;
    h->siz = n;
    for (int i = 1; i <= n; i++) {
        cin >> h->arr[i];
    }
    for (int i = ceil(n/2); i > 0; i--) {
        makeheap(h, i);
    }
    for (int i = 1; i <= n; i++) {
        cout << h->arr[i] << ' ';
    }
}
