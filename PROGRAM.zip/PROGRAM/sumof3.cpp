#include <bits/stdc++.h>

using namespace std;

int main() {
    long long n, k;
    cin >> n >> k;
    pair <long long, long long> a[n];
    for (int i = 0; i < n; i++) {cin >> a[i].first; a[i].second = i+1;}
    sort(a, a+n);
    for (int i = 0; i < n && a[i].first < k; i++) {
        long long fin = k - a[i].first;
        for (int j = i+1; j < n && a[j].first < fin; j++) {
            long long fin2 = fin - a[j].first;
            long long idx = lower_bound(a, a+n, fin2) - a;
            if (idx < n && a[idx].first == fin2) {
                cout << a[i].second << ' ' << a[j].second << ' ' << a[idx].second;
                return 0;
            }
        }
    }
    cout << "IMPOSSIBLE";
}