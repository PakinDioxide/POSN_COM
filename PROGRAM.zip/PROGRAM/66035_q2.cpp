#include <bits/stdc++.h>

using namespace std;

struct node {
    int info;
    struct node *next;
};
typedef struct node *NODEPTR;

NODEPTR head = NULL;

void insert_last(int k) {
    NODEPTR p = new node, q;
    p -> info = k;
    p -> next = NULL;
    if (head == NULL) head = p;
    else {
        for (q = head; q -> next != NULL; q = q -> next);
        q -> next = p;
    }
}

void insert_front(int k) {
    NODEPTR p = new node;
    p -> info = head -> info;
    p -> next = head -> next;
    head -> info = k;
    head -> next = p;
}

void insert_mid(int k) {
    int l, c = 1;
    cout << "Input the position to insert new node : ";
    cin >> l;
    if (l == 1) {
        insert_front(k);
        return;
    }
    NODEPTR p = new node, q, r = NULL;
    q = head;
    while (c < l) {r = q; q = q -> next; c++;}
    p -> info = k;
    r -> next = p;
    p -> next = q;
}

void create(int n){
    for (int i = 0; i < n; i++) {
        int k;
        cout << "Input data for node " << i+1 << " : ";
        cin >> k;
        insert_last(k);
    }
}

void print(){
    NODEPTR p = head;
    while (p != NULL) {
        cout << "DATA = " << p -> info << '\n';
        p = p -> next;
    }
}

int main() {
    int n, k;
    cout << "Input the number of nodes : ";
    cin >> n;
    create(n);
    cout << "\nData entered in the list are :\n";
    print();

    cout << "\nInput data to insert at the beginning of the list : ";
    cin >> k;
    insert_front(k);
    cout << "\nData entered in the list :\n";
    print();
    
    cout << "\nInput data to insert at the end of the list : ";
    cin >> k;
    insert_last(k);
    cout << "\nData, after inserted in the list are :\n";
    print();

    cout << "\nInput data to insert in the middle of the list : ";
    cin >> k;
    insert_mid(k);
    cout << "\nInsertion completed successfully.\n\nThe new list are :\n";
    print();
}