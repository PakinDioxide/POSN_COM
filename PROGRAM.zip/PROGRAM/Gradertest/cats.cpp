#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int n;
    cin >> n;
    long long a[n];
    long long l = 0, r = 0;
    for (int i = 0; i < n; i++) {
        cin >> a[i];
        r = max(a[i], r);
    }
    long long ans = 0;
    while (l <= r) {
        long long mid = (l+r)/2;
        stack <int> s;
        for (int i = 0; i < n; i++) {
            if (s.empty() && a[i] > mid) s.emplace(a[i]);
            else if (!s.empty() && s.top() != a[i] && a[i] > mid)  break;
            else if (!s.empty() && s.top() == a[i] && a[i] > mid) s.pop();
        }
        if (s.empty()) {
            r = mid-1;
            ans = mid;
        } else {
            l = mid+1;
        }
    }
    cout << ans;
}