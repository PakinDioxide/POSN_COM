#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    long long n, m;
    cin >> n >> m;
    long long a[n];
    for (int i = 0; i < n; i++) cin >> a[i];
    sort(a, a+n);
    long long l = 0, r = LLONG_MAX, ans = LLONG_MAX;
    while (l <= r) {
        long long mid = (l+r)/2, k = 0;
        for (int i = 0; i < n && k < m; i++) k += mid/a[i];
        if (k >= m) {
            ans = mid;
            r = mid-1;
        } else l = mid+1;
    }
    cout << ans;
}