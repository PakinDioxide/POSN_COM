#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    cin >> n;
    long long a[n], b[n], c[n];
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 0; i < n; i++) cin >> b[i];
    sort(a, a+n);
    sort(b, b+n);
    long long ans = 0;
    for (int i = 0; i < n; i++) c[i] = a[i] + b[n-i-1];
    sort(c, c+n);
    cout << c[n-1] - c[0];
}