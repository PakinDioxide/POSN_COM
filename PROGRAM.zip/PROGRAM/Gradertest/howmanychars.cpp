/*
LANG: C++
COMPILER: WCB
*/
/*
NAME: Pakin Olanraktham
SID: เลขทะเบียนนักศึกษา 10 หลัก
*/

#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    char k;
    cin >> k;
    int n;
    cin >> n;
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        int ans = 0;
        for (auto j : s) {
            if (j == k) ans++;
        }
        cout << ans << '\n';
    }
}