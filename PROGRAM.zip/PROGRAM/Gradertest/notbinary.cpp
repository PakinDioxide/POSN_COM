#include <stdio.h>

int main() {
    int n;
    scanf("%d", &n);

    int c[n];

    for (int i = 0; i < n; i++) scanf("%d", &c[i]);

    int max = 0;

    for (int i = 1; i < n-1; i++) {
        if (c[i] != c[i+1] && c[i] != c[i-1] && c[i] > max) {
            int temp = 0;
            for (int a = i+1; a < n; a++) {
                if (c[a] == c[i]) break;
                if (c[a] < c[i]) {
                    temp = temp > c[a] ? temp : c[a];
                } else if (c[a] > c[i]) break;
            }
            temp = temp < c[i] ? temp : c[i];
            temp = temp == 0 ? c[i] : temp;
            max = max > temp ? max : temp;
        } else if (c[i] == c[i+1]) i++;
    }

    printf("%d", max);
}