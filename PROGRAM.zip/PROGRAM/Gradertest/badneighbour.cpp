#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    long long n;
    cin >> n;
    long long a[n+1], dp[n+1], dp2[n+1];
    for (long long i = 1; i <= n; i++) cin >> a[i];
    dp[0] = dp2[0] = dp2[1] = 0;
    dp[1] = a[1];
    dp2[2] = a[2];
    for (long long i = 2; i < n; i++) dp[i] = max(dp[i-1], dp[i-2] + a[i]);
    for (long long i = 3; i <= n; i++) dp2[i] = max(dp2[i-1], dp2[i-2] + a[i]);
    cout << max(dp[n-1], dp2[n]);
}
