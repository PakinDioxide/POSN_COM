#include <bits/stdc++.h>

using namespace std;

int recur(int n) {
    
}

int main() {
    int n;
    cin >> n;
    cout << recur(n);
}