#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int n, m, k;
    cin >> n >> m >> k;
    long long a[n][m+1];
    for (int i = 0; i < n; i++) {
        for (int j = 1; j <= m; j++) {
            cin >> a[i][j];
            a[i][j] += a[i][j-1];
        }
    }

    long long ans = LLONG_MIN;

    for (int i = 0; i <= n-k; i++) {
        for (int j = 1; j <= m-k+1; j++) {
            long long sum = 0, sum2 = 0;
            for (int o = i; o < i+k; o++) {
                sum += a[o][j+o-i] - a[o][j-1];
                sum2 += a[o][m-j+1] - a[o][m-j-o+i];
            }
            ans = max({ans, sum, sum2});
        }
    }
    cout << ans;
}