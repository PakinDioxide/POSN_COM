#include <bits/stdc++.h>

using namespace std;

int main() {
    string s;
    cin >> s;
    stack <long long> op, n;
    for (auto i : s) {
        if (i == '[') op.emplace(0);
        else if (i == ']') {
            while (!op.top() == 0) {
                long long x = n.top(), oo = op.top();
                n.pop();
                op.pop();
                long long y = n.top();
                n.pop();
                if (oo == 1) n.emplace((104*(x+y))/100);
                else if (oo == 2) n.emplace((108*(x+y))/100);
                else n.emplace((116*(x+y))/100);
            }
            op.pop();
        } else if (i >= 'A' && i <= 'Z') {
            n.emplace(20);
        } else if (!op.empty() && i-'0' < op.top()) {
            long long x = n.top(), oo = op.top();
            n.pop();
            op.pop();
            long long y = n.top();
            n.pop();
            if (oo == 1) n.emplace((104*(x+y))/100);
            else if (oo == 2) n.emplace((108*(x+y))/100);
            else n.emplace((116*(x+y))/100);
            op.emplace(i-'0');
        } else op.emplace(i-'0');
    }
    while (!op.empty()) {
        long long x = n.top(), oo = op.top();
        n.pop();
        op.pop();
        long long y = n.top();
        n.pop();
        if (oo == 1) n.emplace((104*(x+y))/100);
        else if (oo == 2) n.emplace((108*(x+y))/100);
        else n.emplace((116*(x+y))/100);
    }
    cout << n.top() << '\n';
}