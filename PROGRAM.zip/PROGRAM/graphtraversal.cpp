#include <bits/stdc++.h>

using namespace std;

int n;
vector <vector <int>> adj;
vector <bool> vis;

void dfs(int u) {
    if (vis[u]) return;
    vis[u] = 1;
    for (auto v : adj[u]) dfs(v);
    cout << u << ' ';
}

void bfs(int x) {
    vector <bool> vis2(n);
    queue <int> q;
    q.push(x);
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        if (vis2[u]) continue;
        vis2[u] = 1;
        cout << u << ' ';
        for (auto v : adj[u]) q.push(v);
    }
}

int main() {
    int m;
    cin >> n >> m;
    adj.resize(n);
    vis.resize(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    cout << "BFS : ";
    bfs(0);
    cout << '\n';
    cout << "DFS : ";
    dfs(0);
    cout << '\n';
}