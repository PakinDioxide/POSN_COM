#include <bits/stdc++.h>

using namespace std;

int main() {
    int n, m, k; // k = start point
    cin >> n >> m >> k;
    vector <vector <int>> adj(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    vector <int> dis(n, INT_MAX), vis(n);
    queue <pair <int, int>> q;
    q.push({k, 1});
    dis[k] = 0;
    while (!q.empty()) {
        int u = q.front().first, c = q.front().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        for (auto v : adj[u]) {
            dis[v] = min(c, dis[v]);
            q.push({v, c+1});
        }
    }
    for (auto i : dis) cout << (i == INT_MAX ? -1 : i) << ' ';
}