#include <bits/stdc++.h>

using namespace std;

struct node {
    int info;
    struct node *next;
};
typedef struct node *NODEPTR;

NODEPTR head = NULL;

void insert_last(int k) {
    NODEPTR p = new node, q;
    p -> info = k;
    p -> next = NULL;
    if (head == NULL) head = p;
    else {
        for (q = head; q -> next != NULL; q = q -> next);
        q -> next = p;
    }
}

void create(int n){
    for (int i = 0; i < n; i++) {
        int k;
        cout << "Input data for node " << i+1 << " : ";
        cin >> k;
        insert_last(k);
    }
}

void search(int k) {
    int c = 1;
    NODEPTR q;
    for (q = head; q -> next != NULL; q = q -> next) {
        if (q -> info == k) {cout << "Data found at node " << c << '\n'; return;}
        c++;
    }
    cout << "Data not found\n";
}

void print(){
    NODEPTR p = head;
    while (p != NULL) {
        cout << "DATA = " << p -> info << '\n';
        p = p -> next;
    }
}

int main() {
    int n, k;
    cout << "Input the number of nodes : ";
    cin >> n;
    create(n);
    cout << "\nData entered in the list are :\n";
    print();
    cout << "Input the element to be searched : ";
    cin >> k;
    search(k);
}