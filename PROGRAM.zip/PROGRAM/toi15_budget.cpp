#include <bits/stdc++.h>

using namespace std;

int n, m;
int par[5000];

int fin(int x) {
    if (par[x] != x) par[x] = fin(par[x]);
    return par[x];
}

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    cin >> n >> m;
    for (int i = 0; i < n; i++) par[i] = i;
    priority_queue <pair <int, pair <int, int>>> edge;
    for (int i = 0; i < m; i++) {
        int w, x, y, z;
        cin >> w >> x >> y >> z;
        if (z) par[fin(w)] = fin(x);
        else {
            edge.push({-y, {w, x}});
        }
    }
    int p;
    cin >> p;
    vector <pair <int, int>> pri;
    for (int i = 0; i < m; i++) {
        int x, y;
        cin >> x >> y;
        pri.push_back({x, y});
    }
    sort(pri.begin(), pri.end());
    for (int i = p-1; i > 0; i--) if (pri[i].second < pri[i-1].second) pri[i-1].second = pri[i].second;
    int ans = 0;
    while (!edge.empty()) {
        int x = edge.top().second.first, y = edge.top().second.second, z = -edge.top().first;
        edge.pop();
        if (fin(x) != fin(y)) {
            par[fin(x)] = fin(y);
            int l = 0, r = p, k = 0;
            while (l <= r) {
                int mid = (l+r)/2;
                if (pri[mid].first > z) {
                    r = mid-1;
                    k = pri[mid].second;
                } else l = mid+1;
            }
            ans += k;
        }
    }
    cout << ans;
}