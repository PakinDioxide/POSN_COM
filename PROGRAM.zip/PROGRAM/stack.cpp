#include <iostream>

using namespace std;

#define STSIZE 500

struct stack {
    int size;
    int item[STSIZE];
};

int isempty(struct stack *st) {
    if (st->size == -1) return 1;
    return 0;
}

void push(struct stack *st, int x) {
    if (st->size == STSIZE - 1) {
        cout << "Stack overflow";
        exit(1);
    }
    st->item[(st->size)++] = x;
    return;
}

int pop(struct stack *st) {
    if (st->size == 0) {
        cout << "Stack underflow";
        exit(1);
    }
    return st->item[st->size--];
}

int top(struct stack *st) {
    if (st->size == 0) return -1;
    return st->item[st->size-1];
}

void print(struct stack *st) {
    for (int i = 0; i < st->size; i++) cout << st->item[i] << ' ';
}

int main() {
    struct stack *s = new struct stack, *ind = new struct stack;
    s->size = 0;
    int n, ans = 0;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++) cin >> a[i];
    for (int i = 0; i < n; i++) {
        while (s->size > 2) {
            if (top(s) < a[i]) {
                int x = pop(s);
                pop(ind);
                int len = i - top(ind) - 1;
                int hi = a[i];
                if (hi > top(s)) hi = top(s);
                hi -= x;
                ans += len * hi;
            } else break;
        }
        if (isempty(s) || a[i] <= top(s)) {
            push(s, a[i]);
            push(ind, i);
        }
        
    }
    cout << ans << '\n';
}
