#include <bits/stdc++.h>

using namespace std;

int brute(int n, int k) {
    if (n == 0) return 1;
    return brute(n-1, k)*k;
}

int decon(int n, int k) {
    if (n == 0) return 1;
    int x = decon(n/2, k);
    x *= x;
    if (n%2==1) x *= k;
    return x;
}

int main() {
    int n, k;
    cin >> n >> k;
    cout << brute(k, n) << ' ' << decon(k, n);
}