#include <bits/stdc++.h>

using namespace std;

int n, m;
vector <vector <int>> adj;
vector <bool> vis;
string name[] = {"Physics", "Math", "Chem", "Soc", "Psych", "Econ", "Eng", "Hist"};

void dfs(int u) {
    if (vis[u]) return;
    vis[u] = true;
    for (auto v : adj[u]) dfs(v);
    cout << name[u] << ' ';
}

int main() {
    cin >> n >> m;
    adj.resize(n);
    vis.resize(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
    }
    dfs(0);
    cout << '\n';
}
/*
8 28
0 1
0 2
1 3
1 4
1 2
1 0
2 0
2 1
2 3
2 4
3 7
3 6
3 5
3 4
3 2
3 1
4 2
4 1
4 3
4 5
5 4
5 3
5 6
6 5
6 3
6 7
7 6
7 3
*/