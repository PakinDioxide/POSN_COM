#include <bits/stdc++.h>

using namespace std;

long long solve(string s) {
    if (s.size() == 1) return s[0] - '0';
    long long k = 0;
    for (auto i : s) k += i - '0';
    return solve(to_string(k));
}

int main() {
    string s;
    int k;
    cin >> s >> k;
    int n = s.size();
    for (int i = 1; i < k; i++) s += s.substr(0, n);
    cout << solve(s);
}