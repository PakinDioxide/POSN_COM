#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int n, p, r, m;
    cin >> n >> p >> r >> m;
    vector <vector <pair <int, int>>> adj(n);
    for (int i = 0; i < m; i++) {
        int x, y, w;
        cin >> x >> y >> w;
        adj[x].push_back({y, w});
    }
    priority_queue <pair <int, int>> q;
    vector <pair <int, int>> dis(n, {INT_MAX, 0});
    vector <bool> vis(n);
    dis[p] = {0, 0};
    q.push({0, p});
    while (!q.empty()) {
        int u = q.top().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        for (auto z : adj[u]) {
            int v = z.first, w = z.second;
            if (u != p) w += 10;
            if (dis[u].first + w < dis[v].first) {
                dis[v].first = dis[u].first + w;
                dis[v].second = dis[u].second;
                if (u != p) dis[v].second++;
                q.push({-dis[v].first, v});
            }
        }
    }
    cout << dis[r].first << ' ' << dis[r].second << '\n';
    int l;
    cin >> l;
    for (int o = 0; o < l; o++) {
        int k;
        cin >> k;
        cout << dis[r].first + dis[r].second*(k-10) << ' ';
    }
}