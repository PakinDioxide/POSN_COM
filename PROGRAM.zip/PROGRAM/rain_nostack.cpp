#include <iostream>

using namespace std;

int main() {
    int n, ans = 0, t = -1, c = 0;
    cin >> n;
    for (int i = 0; i < n; i++) {
        int k;
        cin >> k;
        if (k < t) {
            c += t-k;
        } else {
            ans += c;
            c = 0;
        }
        t = max(k, t);
    }
    cout << ans << '\n';
}