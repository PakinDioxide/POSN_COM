#include <bits/stdc++.h>

using namespace std;

int main() {
    int n, m = INT_MAX, ans = INT_MAX, p;
    cin >> n;
    vector <pair <int, int>> a(n);
    for (int i = 0; i < n; i++) {
        cin >> a[i].second;
        m = min(a[i].second, m);
    }
    for (int i = 0; i < n; i++) cin >> a[i].first;
    sort(a.begin(), a.end());
    for (int i = 1; i <= a[0].first; i++) {
        int k = 0;
        for (int j = 0; j < n; j++) {
            k += a[j].first - i;
        }
        if (ans > k) {
            ans = k;
            p = i;
        }
    }
    cout << p << ' ' << ans;
}