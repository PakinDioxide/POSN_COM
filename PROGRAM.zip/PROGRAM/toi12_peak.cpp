#include <bits/stdc++.h>

using namespace std;

int main() {
    ios::sync_with_stdio(0), cin.tie(0);
    int n, k;
    scanf("%d%d", &n, &k);
    vector <int> s;
    map <int, bool> ok;
    int a[n+2];
    a[0] = -1;
    a[n+1] = -1;
    for (int i = 1; i <= n+1; i++) {
        if (i <= n) scanf("%d", &a[i]);
        if (i > 1 && a[i-1] > a[i-2] && a[i-1] > a[i] && !ok[a[i-1]]) {s.push_back(a[i-1]); ok[a[i-1]] = 1;}
    }
    if (s.empty()) {
        printf("-1");
        return 0;
    }
    int c = 0;
    sort(s.begin(), s.end());
    if (s.size() < k) for (auto i : s) printf("%d\n", i);
    else for (int i = s.size()-1; c < k; i--) {printf("%d\n", s[i]); c++;}
}