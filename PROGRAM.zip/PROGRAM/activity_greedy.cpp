#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector <pair <pair <int, int>, int>> a(n);
    for (int i= 0; i < n; i++) {
        cin >> a[i].first.second >> a[i].first.first;
        a[i].second = i+1;
    }
    sort(a.begin(), a.end());
    cout << "The class to learn : " << a[0].second << ' ';
    int r = a[0].first.first, ans = 1;
    for (int i = 1; i < n; i++) {
        if (a[i].first.second >= r) {ans++; r = a[i].first.first; cout << a[i].second << ' ';}
    }
    cout << "\nNumbers of class : " << ans << '\n';
}
/*
6
5 9
1 2
3 4
0 6
5 7
8 9

11
1 4
3 5
0 6
5 7
3 9
5 9
6 10
8 11
8 12
2 14
12 16
*/