#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    cin >> n;
    int m[n], h[n];
    for (int i = 0; i < n; i++) cin >> m[i];
    for (int i = 0; i < n; i++) cin >> h[i];
    sort(m, m+n);
    sort(h, h+n);
    int ans = 0;
    for (int i = 0; i < n; i++) ans = max(abs(m[i]-h[i]), ans);
    cout << ans << '\n';
}