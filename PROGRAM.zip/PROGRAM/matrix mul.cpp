#include <bits/stdc++.h>

using namespace std;

int main() {
    int n, m, x, y;
    cin >> n >> m >> x >> y;
    int a[n][m], b[x][y];
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) cin >> a[i][j];
    }
    for (int i = 0; i < x; i++) {
        for (int j = 0; j < y; j++) cin >> b[i][j];
    }
    int c[n][y];
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < y; j++) {
            int k = 0;
            for (int l = 0; l < m; l++) {
                k += a[i][l] * b[l][j];
            }
            c[i][j] = k;
        }
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < y; j++) {
            cout << c[i][j];
        }
        cout << '\n';
    }
}