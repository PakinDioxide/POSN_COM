#include <bits/stdc++.h>

using namespace std;

struct node {
    int info;
    struct node *next;
};
typedef struct node *NODEPTR;

NODEPTR head = NULL;

void insert_last(int k) {
    NODEPTR p = new node, q;
    p -> info = k;
    p -> next = NULL;
    if (head == NULL) head = p;
    else {
        for (q = head; q -> next != NULL; q = q -> next);
        q -> next = p;
    }
}

void delete_front() {
    NODEPTR p;
    p = head -> next;
    head -> info = p -> info;
    head -> next = p -> next;
    delete p;
}

void delete_last() {
    NODEPTR p, q;
    if (head == NULL) return;
    else {
        for (q = head; q -> next -> next != NULL; q = q -> next);
        p = q -> next;
        q -> next = NULL;
        delete p;
    }
}

void delete_mid(int l) {
    int c = 0;
    if (l == 1) {
        delete_front();
        return;
    }
    NODEPTR p = new node, q, r = NULL;
    q = head;
    while (c < l) {r = q; q = q -> next; c++;}
    r -> next = p -> next;
    delete p;
}

void create(int n){
    for (int i = 0; i < n; i++) {
        int k;
        cout << "Input data for node " << i+1 << " : ";
        cin >> k;
        insert_last(k);
    }
}

void print(){
    NODEPTR p = head;
    while (p != NULL) {
        cout << "DATA = " << p -> info << '\n';
        p = p -> next;
    }
}

int main() {
    int n, k;
    cout << "Input the number of nodes : ";
    cin >> n;
    create(n);
    cout << "\nData entered in the list are :\n";
    print();

    cout << "\nData of node 1 which is being deleted is : " << head -> info << '\n';
    delete_front();
    cout << "\nData, after deletion of first node :\n";
    print();

    delete_last();
    cout << "\nThe new list after deletion the last node are :\n";
    print();

    cout << "\nInput the position of node to delete : ";
    cin >> k;
    delete_mid(k);
    cout << "\nDeletion completed successfully.\n\nThe new list are :\n";
    print();
}