#include <bits/stdc++.h>

using namespace std;

int main() {
    long long n;
    cin >> n;
    long long a[n];
    for (int i = 0; i < n; i++) cin >> a[i];
    sort(a, a+n);
    long long q;
    cin >> q;
    for (int i = 0; i < q; i++) {
        long long k;
        cin >> k;
        long long idx = upper_bound(a, a+n, k) - a;
        if (a[idx] > k) cout << idx << '\n';
        else cout << idx+1;
    }
}