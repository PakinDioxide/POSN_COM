#include <bits/stdc++.h>

using namespace std;

int n, x, y;
long long ans = 0, MOD = 1e9+7;
vector <set <int>> adj;
vector <int> vis;

int dfs(int u) {
    if (u == y) return 1; 
    long long k = 0;
    for (auto v : adj[u]) {
        if (vis[v]) continue;
        vis[v] = 1;
        cout << u << ' ';
        k = (k + dfs(v)) % MOD;
        vis[v] = 0;
    }
    return k;
}

int main() {
    cin >> n;
    adj.resize(n);
    vis.resize(n);
    cin >> x;
    x--;
    for (int i = 0; i < 2*n-2; i++) {
        cin >> y;
        y--;
        adj[x].insert(y);
        adj[y].insert(x);
        x = y;
    }
    cout << dfs(y);
}