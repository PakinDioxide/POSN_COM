#include <bits/stdc++.h>

using namespace std;

int n, m;
vector <vector <int>> adj;
vector <bool> vis;
stack <int> q;

void dfs(int u) {
    if (vis[u]) return;
    vis[u] = 1;
    for (auto v : adj[u]) {
        if (!vis[v]) dfs(v);
    }
    q.push(u);
}

int main() {
    cin >> n >> m;
    adj.resize(n);
    vis.resize(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        u--;
        v--;
        adj[u].push_back(v);
    }
    for (int i = 0; i < n; i++) {
        if (!vis[i]) dfs(i);
    }
    while (!q.empty()) {cout << q.top()+1 << ' '; q.pop();}
    cout << '\n';
}
/*
9 15
1 2
1 3
1 5
2 4
2 5
3 5
3 6
4 7
5 6
5 7
5 9
6 8
7 9
8 7
8 9
*/