#include <bits/stdc++.h>

using namespace std;

int n;
vector <int> a;

int bs(int l, int r) {
    if (l >= r) return -1;
    int mid = (l+r)/2;
    if (mid > 0) {
        if (a[mid-1] == a[mid]) {
            return mid;
        }
    }
    if (mid < n-1) {
        if (a[mid+1] == a[mid]) {
            return mid;
        }
    }
    if (a[mid] < mid+1) {
        return bs(l, mid-1);
    }
    else return bs(mid+1, r);
}

int main() {
    cin >> n;
    a.resize(n);
    for (int i = 0; i < n; i++) cin >> a[i];
    sort(a.begin(), a.end());
    int l = 0, r = n-1;
    int idx = bs(l, r);
    if (idx >= 0) cout << a[idx];
    else cout << "No duplicate";
}