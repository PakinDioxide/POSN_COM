#include <bits/stdc++.h>

using namespace std;

void findPer(int a[], int n) {
    sort(a, a+n);
    do {
        for (int i = 0; i < n; i++) cout << a[i] << ' ';
        cout << '\n';
    } while (next_permutation(a, a+n));
}

int main() {
    int n;
    cin >> n;
    int a[n];
    for (int i = 0; i < n; i++) cin >> a[i];
    findPer(a, n);
}