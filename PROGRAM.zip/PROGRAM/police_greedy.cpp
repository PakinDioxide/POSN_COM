#include <bits/stdc++.h>

using namespace std;

int main() {
    vector <int> pol, the;
    int n, k;
    cin >> n >> k;
    for (int i = 0; i < n; i++) {
        char k;
        cin >> k;
        if (k == 'P') pol.push_back(i);
        else the.push_back(i);
    }
    int p = 0, t = 0, ans = 0;
    while (p < pol.size() && t < pol.size()) {
        if (abs(pol[p] - the[t] <= k)) {
            p++;
            t++;
            ans++;
        } else if (pol[p] < the[t]) p++;
        else t++;
    }
    cout << ans << '\n';
}